// script.js
const texts = [
    "Real-time parking availability",
    "Reservation & pre-booking",
    "Scan & Pay",
    "Automatic Entry and Exit",
    "EV charging point navigator",
  ];
  
  const feature1 = document.getElementById('features');
  
  let currentIndex = 0;
  
  function updateText() {
    feature1.style.opacity = 0;
  
    setTimeout(() => {
      feature1.textContent = texts[currentIndex];
  
      feature1.style.opacity = 1;
  
      currentIndex = (currentIndex + 1) % texts.length;
    }, 400);  
  }
  
  setInterval(updateText, 3000);
  
  updateText();
//   for slider
  let currentIndex1 = 0;

function showSlide(index) {
  const slides = document.querySelectorAll('.slides img');
  
  if (index >= slides.length) {
    currentIndex1 = 0;
  } else if (index < 0) {
    currentIndex1 = slides.length - 1;
  } else {
    currentIndex1 = index;
  }

  slides.forEach((slide) => slide.classList.remove('active'));
  slides[currentIndex1].classList.add('active');
}

showSlide(currentIndex1);

function moveSlide(step) {
  showSlide(currentIndex1 + step);
}

setInterval(() => {
  moveSlide(1);
}, 3000);

function searchNearbyParking() {
  alert('Redirecting to nearby parking search page...');
  window.location.href = '/searchnear.html';
}

function checkOccupancy() {
  alert('Checking parking occupancy...');
  window.location.href = '/occupancy.html';
}

function searchChargingStations() {
  alert('Redirecting to EV charging stations search page...');
  window.location.href = '/nearbyEV.html'; 
}


function makeReservation() {
  alert('Redirecting to reservation page...');
  window.location.href = '/reserve.html';
}

  
  //pop up
  document.getElementById("reserve").addEventListener("click", function (event) {
  event.preventDefault();
  fetch('reserve.html')
      .then(response => response.text())
      .then(html => {
          const popup = new DOMParser().parseFromString(html, 'text/html').querySelector('.popup');
          if (popup) {
              document.body.appendChild(popup);
              popup.style.display = "flex";
          }
      });
  });
  


//   document.getElementById("reserve").addEventListener("click", function (event) {
//     event.preventDefault(); // Prevent default redirection

//     fetch('/reserve/?showPopup=true') // Fetch the Django view
//         .then(response => response.text())
//         .then(html => {
//             const popupContainer = document.createElement('div');
//             popupContainer.innerHTML = html;

//             // Extract and show only the reservation form
//             const popup = popupContainer.querySelector('form');
//             if (popup) {
//                 popup.style.display = "block";
//                 document.body.appendChild(popup);
//             }
//         });
// });

  