// sign-login.js
const container = document.getElementById('container1');
const registerBtn = document.getElementById('register');
const loginBtn=document.getElementById('login');

registerBtn.addEventListener('click', ()=>{
    container.classList.add("active");
});
loginBtn.addEventListener('click', ()=>{
    container.classList.remove("active");
});


const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get('showPopup') === 'true') {
    document.querySelector(".popup").style.display = "flex";
}

document.querySelectorAll(".close").forEach(function(closeButton) {
    closeButton.addEventListener("click", function() {
        document.querySelector(".popup").style.display = "none";  // Hide the popup
    });
    
});




