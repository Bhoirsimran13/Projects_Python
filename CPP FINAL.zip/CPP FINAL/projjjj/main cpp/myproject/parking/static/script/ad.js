

document.addEventListener("DOMContentLoaded", function () {
    const container1 = document.getElementById('container2');
    const registerBtn1 = document.getElementById('register1');
    const loginBtn1 = document.getElementById('login1');

    if (registerBtn1 && container1) {
        registerBtn1.addEventListener('click', () => {
            container1.classList.add("active");
        });
    }

    if (loginBtn1 && container1) {
        loginBtn1.addEventListener('click', () => {
            container1.classList.remove("active");
        });
    }

    // Show popup on page load if 'showPopup1' is in the URL
    const urlParams1 = new URLSearchParams(window.location.search);
    if (urlParams1.get('showPopup1') === 'true') {
        let popup = document.querySelector(".popup1");
        if (popup) {
            popup.style.display = "flex";
        }
    }

    // **Handle login success and close popup**
    setTimeout(function () {
        var successMessage = document.querySelector(".alert.success");
        if (successMessage) {
            let popup = document.querySelector(".popup1");
            if (popup) {
                popup.style.display = "none"; // Auto-close popup
            }
        }
    }, 1000);
});









