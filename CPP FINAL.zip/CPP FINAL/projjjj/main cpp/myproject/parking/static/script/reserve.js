// res.js
const locations = {
    Pune: ["Slot 1", "Slot 2", "Slot 3", "Slot 4"],
    Mumbai: ["Slot 1", "Slot 2", "Slot 3", "Slot 4"],
    Delhi: ["Slot 1", "Slot 2", "Slot 3", "Slot 4"],
    Bangalore: ["Slot 1", "Slot 2", "Slot 3", "Slot 4"]
};

const locationSelect = document.getElementById("location");
const slotSelect = document.getElementById("slot");
const bookNowButton = document.getElementById("bookNow");
const slotStatus = document.getElementById("slotStatus");
const graceTimerDiv = document.getElementById("graceTimer");
const reservationTimerDiv = document.getElementById("reservationTimer");
const graceTimeSpan = document.getElementById("graceTimeRemaining");
const reservationTimeSpan = document.getElementById("reservationTimeRemaining");
const durationRange = document.getElementById("duration");
const durationValue = document.getElementById("durationValue");
const priceDisplay = document.getElementById("price");

let bookedSlots = new Set();

locationSelect.addEventListener("change", () => {
    const selectedLocation = locationSelect.value;
    slotSelect.innerHTML = '<option value="">-- Select Slot --</option>';
    slotSelect.disabled = !selectedLocation;

    if (selectedLocation) {
        locations[selectedLocation].forEach(slot => {
            const option = document.createElement("option");
            option.value = slot;
            option.textContent = slot;
            slotSelect.appendChild(option);
        });
        displaySlots(selectedLocation);
    }
});

function displaySlots(location) {
    slotStatus.innerHTML = "";
    locations[location].forEach(slot => {
        const div = document.createElement("div");
        div.textContent = slot;
        div.className = "slot";
        if (bookedSlots.has(slot)) {
            div.classList.add("booked");
        } else {
            div.addEventListener("click", () => {
                if (!div.classList.contains("booked")) {
                    slotSelect.value = slot;
                }
            });
        }
        slotStatus.appendChild(div);
    });
}

durationRange.addEventListener("input", () => {
    const hours = parseInt(durationRange.value, 10);
    durationValue.textContent = `${hours} Hour${hours > 1 ? "s" : ""}`;
    priceDisplay.textContent = `Parking Price: ₹${hours * 50}`;
});

bookNowButton.addEventListener("click", () => {
    const location = locationSelect.value;
    const slot = slotSelect.value;

    if (!location || !slot) {
        alert("Please fill in all fields.");
        return;
    }

    if (bookedSlots.has(slot)) {
        alert("Slot is already booked!");
        return;
    }

    bookedSlots.add(slot);
    alert(`Slot ${slot} booked successfully for ${durationRange.value} hour(s)!`);
    startGracePeriod(slot, 30); // 30-minute grace period
    startReservationPeriod(slot, parseInt(durationRange.value, 10)); // Selected reservation period
    displaySlots(location);
});

function startGracePeriod(slot, minutes) {
    graceTimerDiv.style.display = "block";
    const endTime = new Date().getTime() + minutes * 60 * 1000;

    const interval = setInterval(() => {
        const now = new Date().getTime();
        const remainingTime = endTime - now;

        if (remainingTime <= 0) {
            clearInterval(interval);
            alert(`Grace period expired! Slot ${slot} is now unreserved.`);
            bookedSlots.delete(slot);
            displaySlots(locationSelect.value);
            graceTimerDiv.style.display = "none";
        } else {
            const minutes = Math.floor((remainingTime / (1000 * 60)) % 60);
            const seconds = Math.floor((remainingTime / 1000) % 60);
            graceTimeSpan.textContent = `${minutes}:${seconds.toString().padStart(2, "0")}`;
        }
    }, 1000);
}

function startReservationPeriod(slot, hours) {
    reservationTimerDiv.style.display = "block";
    const endTime = new Date().getTime() + hours * 60 * 60 * 1000;

    const interval = setInterval(() => {
        const now = new Date().getTime();
        const remainingTime = endTime - now;

        if (remainingTime <= 0) {
            clearInterval(interval);
            alert(`Reservation period ended for Slot ${slot}.`);
            bookedSlots.delete(slot);
            displaySlots(locationSelect.value);
            reservationTimerDiv.style.display = "none";
        } else {
            const hours = Math.floor(remainingTime / (1000 * 60 * 60));
            const minutes = Math.floor((remainingTime / (1000 * 60)) % 60);
            const seconds = Math.floor((remainingTime / 1000) % 60);
            reservationTimeSpan.textContent = `${hours}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
        }
    }, 1000);
}






