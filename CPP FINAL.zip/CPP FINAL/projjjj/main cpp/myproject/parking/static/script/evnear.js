

// Initialize the map
const map = L.map('map').setView([20.5937, 78.9629], 5); // Default center: India

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Marker group
const markerGroup = L.layerGroup().addTo(map);

// Function to search location and parking spaces
async function searchLocation() {
    const locationInput = document.getElementById('locationInput').value.trim();
    const loadingElement = document.getElementById('loading');

    if (!locationInput) {
        alert('Please enter a location!');
        return;
    }

    loadingElement.style.display = 'block';

    // Geocode the location
    try {
        const geocodeResponse = await fetch(
            `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(locationInput)}`
        );
        const geocodeData = await geocodeResponse.json();

        if (geocodeData.length === 0) {
            alert('Location not found. Please try again.');
            return;
        }

        const { lat, lon } = geocodeData[0];
        const userLocation = [parseFloat(lat), parseFloat(lon)];
        map.setView(userLocation, 12);

        // Clear previous markers
        markerGroup.clearLayers();

        // Fetch nearby parking spaces using Overpass API
        const overpassQuery = `
            [out:json];
            node["amenity"="parking"](around:15000, ${lat}, ${lon});
            out body;
        `;
        const overpassResponse = await fetch('https://overpass-api.de/api/interpreter', {
            method: 'POST',
            body: overpassQuery,
        });
        const overpassData = await overpassResponse.json();

        if (overpassData.elements.length === 0) {
            alert('No EV charging stations found in this area.');
            return;
        }

        // Add markers for parking spaces
        overpassData.elements.forEach((parking) => {
            const parkingName = parking.tags.name || 'EV Charging Station';
            const parkingLat = parking.lat;
            const parkingLon = parking.lon;

            // Construct route URL (using Google Maps for simplicity)
            const routeLink = `https://www.google.com/maps/dir/?api=1&destination=${parkingLat},${parkingLon}`;

            // Create marker with popup including name and route link
            L.marker([parkingLat, parkingLon])
                .bindPopup(`
                    <b>${parkingName}</b><br>
                    <a href="${routeLink}" target="_blank" style="color: #28a745; text-decoration: none;">
                        Get Directions
                    </a>
                `)
                .addTo(markerGroup);
        });

    } catch (error) {
        console.error(error);
        alert('An error occurred while searching for parking spaces. Please try again later.');
    } finally {
        loadingElement.style.display = 'none';
    }
}