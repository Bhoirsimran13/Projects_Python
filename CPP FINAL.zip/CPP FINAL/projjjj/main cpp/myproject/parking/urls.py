# urls.py
from django.contrib import admin 
from django.urls import path
from parking import views 
from .views import gate_control
urlpatterns = [
    path('admin/', admin.site.urls), 
    path('', views.home, name='home'), 
    path('index.html', views.home, name='home'),
    path('parking_status/', views.parking_status, name='parking_status'),
    path('searchnear.html', views.searchnear, name='search_parking'), 
    path('nearbyEV.html', views.evnear, name='search_ev'),
    path("reserve.html", views.reserve_parking, name="reserve_parking"),
    path('sign-up/', views.sign_up, name='sign_up'),
    path('sign-in/', views.sign_in, name='sign_in'),
    
    path('sign-up1/', views.sign_up1, name='sign_up1'),
    path('sign-in1/', views.sign_in1, name='sign_in1'),
    path('dashboard', views.booking_dashboard, name='booking_dashboard'),
    # path('parking-status/', views.parking_status, name="parking_status"),
    path('gate/', gate_control, name='gate_control'),
    path('verify-otp/', views.verify_otp, name='verify_otp'),
    path('send_otp/', views.send_otp, name='send_otp'),
    path('payment/', views.payment_view, name='payment'),
    path('contact/', views.contact_view, name='contact'),
    path('about/', views.about_us, name='about'),
    ]
