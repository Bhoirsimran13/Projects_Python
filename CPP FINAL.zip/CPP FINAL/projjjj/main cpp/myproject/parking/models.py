from django.db import models
from django.utils.timezone import now
import datetime

class ParkingReservation(models.Model):
    full_name = models.CharField(max_length=100)
    email = models.EmailField()
    car_number = models.CharField(max_length=20)
    location = models.CharField(max_length=100)
    slot = models.CharField(max_length=100, default='Slot 1')  # Corrected indentation here
    booking_time = models.DateTimeField()
    duration = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        return f"Reservation for {self.full_name} on {self.booking_time}"




class User(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=200)  # Store encrypted password
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name
    

    

class AdminUser(models.Model):
    ad_name = models.CharField(max_length=100)
    ad_email = models.EmailField(unique=True)
    ad_password = models.CharField(max_length=200)  # Store encrypted password
    ad_created_at = models.DateTimeField(default=now)

    def __str__(self):
        return self.ad_name
   






class ContactMessage(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Message from {self.name}"