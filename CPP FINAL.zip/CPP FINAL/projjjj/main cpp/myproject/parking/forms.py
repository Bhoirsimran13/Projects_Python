from django import forms
from .models import ParkingReservation
from .models import ContactMessage

class ParkingForm(forms.ModelForm):
    class Meta:
        model = ParkingReservation
        fields = ['full_name', 'email', 'car_number', 'location', 'slot', 'booking_time', 'duration', 'price']




class ContactForm(forms.ModelForm):
    class Meta:
        model = ContactMessage
        fields = ['name', 'email', 'phone', 'message']