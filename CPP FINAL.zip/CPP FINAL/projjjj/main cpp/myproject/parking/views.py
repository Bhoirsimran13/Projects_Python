# views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from .models import ParkingReservation
from django.utils.timezone import make_aware
from datetime import datetime
from threading import Thread
from .models import User
from django.contrib.auth.hashers import make_password
from django.contrib.auth.hashers import check_password
from .models import AdminUser
import requests
from django.core.cache import cache
from .forms import ContactForm
import random



def home(request):
    return render(request, 'index.html') 
    

def parking_status(request):
    parking_spots = [
        {'number': 1, 'status': 'Available'},
        {'number': 2, 'status': 'Occupied'},
        {'number': 3, 'status': 'Available'},
        {'number': 4, 'status': 'Occupied'},
    ]
    return render(request, 'occupancy.html', {'parking_spots': parking_spots})

def searchnear(request):
    return render(request,'searchnear.html')


def evnear(request):
    return render(request,'nearbyEV.html')


# This function will send the email asynchronously
def send_confirmation_email(subject, message, from_email, recipient_email):
    send_mail(subject, message, from_email, [recipient_email])

def reserve_parking(request):
    if request.method == "POST":
        # Get form data
        full_name = request.POST.get('fullName')
        email = request.POST.get('email')
        car_number = request.POST.get('carNumber')
        location = request.POST.get('location')
        slot = request.POST.get('slot')
        booking_time = request.POST.get('bookingTime')
        duration = int(request.POST.get('duration'))
        price = 50 * duration  # Example: ₹50 per hour

        # Make sure the booking time is in the correct timezone
        booking_time = make_aware(datetime.strptime(booking_time, "%Y-%m-%dT%H:%M"))

        # Create reservation in the database
        reservation = ParkingReservation(
            full_name=full_name,
            email=email,
            car_number=car_number,
            location=location,
            slot=slot,
            booking_time=booking_time,
            duration=duration,
            price=price
        )
        reservation.save()

        # Prepare email subject and message
        subject = 'Parking Reservation Confirmation'
        message = f"""
        Hello {full_name},

        Your parking reservation has been successfully booked with the following details:

        Car Number: {car_number}
        Location: {location}
        Parking Slot: {slot}
        Booking Time: {booking_time.strftime('%Y-%m-%d %H:%M:%S')}
        Duration: {duration} hour(s)
        Price: ₹{price}

        Thank you for using our Smart Parking System.

        Best Regards,
        Smart Parking System Team
        """
        from_email = settings.DEFAULT_FROM_EMAIL

        # Show success message first
        success_message = 'Your reservation has been successfully made! A confirmation email has been sent to your email address.'

        # Send email asynchronously in a separate thread
        email_thread = Thread(target=send_confirmation_email, args=(subject, message, from_email, email))
        email_thread.start()

        # Return success message to the user and render the page
        return render(request, 'reserve.html', {
            'message': success_message
        })

    return render(request, 'reserve.html')




def sign_up(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Validate empty fields
        if not name or not email or not password :
            messages.error(request, 'All fields are required!')
            return redirect('reserve_parking')  # Reload page with error message

        # Check if email already exists
        if AdminUser.objects.filter(email=email).exists():
            messages.error(request, 'Email already registered!')
            return redirect('reserve_parking')

        # Encrypt the password
        encrypted_password = make_password(password)

        # Store user in the database
        AdminUser.objects.create(name=name, email=email, password=encrypted_password )

        # Success message
        messages.success(request, 'Registration Successful!')

        return redirect('reserve_parking')  

    return render(request, 'reserve.html')



def sign_in(request): 
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Validate empty fields
        if not email or not password:
            messages.error(request, 'Both email and password are required!')
            return redirect('reserve_parking')  # Reloads page

        # Check if email exists
        user = User.objects.filter(email=email).first()
        if not user:
            messages.error(request, 'No account found with this email. Please register first!')
            return redirect('reserve_parking')

        # Validate password
        if not check_password(password, user.password):
            messages.error(request, 'Incorrect password! Please try again.')
            return redirect('reserve_parking')

        # Successful login
        messages.success(request, f'Welcome {user.name}, you have successfully signed in!')
        return redirect('reserve_parking')  # Reloads page

    return redirect('reserve_parking')






def sign_up1(request):
    if request.method == 'POST':
        ad_name = request.POST.get('name1')
        ad_email = request.POST.get('email1')
        ad_password = request.POST.get('password1')

        # Validate empty fields
        if not ad_name or not ad_email or not ad_password :
            messages.error(request, 'All fields are required!')
            return redirect('booking_dashboard')  # Reload page with error message

        # Check if email already exists
        if AdminUser.objects.filter(ad_email=ad_email).exists():
            messages.error(request, 'Email already registered!')
            return redirect('booking_dashboard')

        # Encrypt the password
        encrypted_password = make_password(ad_password )

        # Store user in the database
        AdminUser.objects.create(ad_name=ad_name, ad_email=ad_email, ad_password =encrypted_password )

        # Success message
        messages.success(request, 'Registration Successful!')

        return redirect('booking_dashboard')  

    return render(request, 'booking_dashboard.html')



def sign_in1(request): 
    if request.method == 'POST':
        ad_email = request.POST.get('email1')
        ad_password = request.POST.get('password1')

        # Validate empty fields
        if not ad_email or not ad_password:
            messages.error(request, 'Both email and password are required!')
            return redirect('booking_dashboard')  # Reloads page

        # Check if email exists
        user1 = AdminUser.objects.filter(ad_email=ad_email).first()
        if not user1:
            messages.error(request, 'No account found with this email. Please register first!')
            return redirect('booking_dashboard')

        # Validate password
        if not check_password(ad_password, user1.ad_password):
            messages.error(request, 'Incorrect password! Please try again.')
            return redirect('booking_dashboard')

        # Successful login
        messages.success(request, f'Welcome {user1.ad_name}, you have successfully signed in!')
        return redirect('booking_dashboard')  # Reloads page

    return redirect('booking_dashboard')


def booking_dashboard(request):
    reservations = ParkingReservation.objects.all()  # Show latest first
    return render(request, 'booking_dashboard.html', {'reservations': reservations})


THINGSPEAK_CHANNEL_ID = "2842234"
THINGSPEAK_API_URL = f"https://api.thingspeak.com/channels/{THINGSPEAK_CHANNEL_ID}/feeds.json?results=1"

def parking_status(request):
    try:
        # Fetch data from ThingSpeak API
        response = requests.get(THINGSPEAK_API_URL)
        data = response.json()

        # Debug: Print API response
        print("ThingSpeak API Response:", data)

        # Extract latest data
        if isinstance(data, dict) and "feeds" in data and isinstance(data["feeds"], list) and len(data["feeds"]) > 0:
            latest_entry = data["feeds"][0]

            # Ensure fields exist in the response
            slot1 = latest_entry.get("field1", "N/A")
            slot2 = latest_entry.get("field2", "N/A")
            slot3 = latest_entry.get("field3", "N/A")
            slot4 = latest_entry.get("field4", "N/A")
            entry = latest_entry.get("field5", "N/A")

            # Convert to string if needed
            slot1 = str(slot1) if slot1 is not None else "N/A"
            slot2 = str(slot2) if slot2 is not None else "N/A"
            slot3 = str(slot3) if slot3 is not None else "N/A"
            slot4 = str(slot4) if slot4 is not None else "N/A"
            entry = str(entry) if entry is not None else "N/A"

            # Prepare context for template
            context = {
                "slot1": slot1,
                "slot2": slot2,
                "slot3": slot3,
                "slot4": slot4,
                "entry": entry,
            }
        else:
            context = {"error": "No data available!"}

    except Exception as e:
        context = {"error": f"Error fetching data: {str(e)}"}

    return render(request, "parking_status.html", context)


from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
# views.py
def gate_control(request):
    if request.method == 'POST':
        try:
            response = requests.get('http://192.168.173.146/opengate')  # Replace <NodeMCU_IP> with actual IP
            if response.status_code == 200:
                message = 'Gate Opened Successfully!'
            else:
                message = f'Failed to open gate. Status Code: {response.status_code}'
        except Exception as e:
            message = f'Error: {str(e)}'
        return render(request, 'gate_control.html', {'message': message})
    return render(request, 'gate_control.html')











# def payment_view(request):
#     name = request.GET.get('name', '')
#     email = request.GET.get('email', '')
#     car_number = request.GET.get('car_number', '')
#     location = request.GET.get('location', '')
#     slot = request.GET.get('slot', '')
#     amount = request.GET.get('amount', '0')

#     print(f"Received Data -> Name: {name}, Email: {email}, Car: {car_number}, Location: {location}, Slot: {slot}, Amount: {amount}")

#     context = {
#         'name': name,
#         'email': email,
#         'car_number': car_number,
#         'location': location,
#         'slot': slot,
#         'amount': amount
#     }
#     return render(request, 'payment.html', context)







def payment_view(request):
    name = request.GET.get('name', '')
    email = request.GET.get('email', '')
    car_number = request.GET.get('car_number', '')
    location = request.GET.get('location', '')
    slot = request.GET.get('slot', '')
    amount = request.GET.get('amount', '0')

    if not slot:
        print("⚠️ Slot value is missing in the request!")

    print(f"📌 Received Data -> Name: {name}, Email: {email}, Car: {car_number}, Location: {location}, Slot: {slot}, Amount: {amount}")

    context = {
        'name': name,
        'email': email,
        'car_number': car_number,
        'location': location,
        'slot': slot,
        'amount': amount
    }
    return render(request, 'payment.html', context)







# ✅ Temporary Storage for OTP
otp_storage = {}

# ✅ Function to Send OTP

def send_otp(request):
    if request.method == 'POST':
        email = request.POST.get('email')

        # ✅ Generate OTP
        otp = random.randint(100000, 999999)

        # ✅ Store OTP in Django Cache (Valid for 5 Minutes)
        cache.set(email, otp, timeout=300)  # 300 seconds = 5 minutes

        # ✅ Debug: Print OTP in the server logs for testing
        print(f"OTP for {email}: {otp}")

        # ✅ Send OTP via Email
        subject = '🔐 Your OTP Verification Code'
        message = f"""
        Hello,

        Your OTP Verification Code is: {otp}

        Please do not share this OTP with anyone.
        This OTP will expire in 5 minutes.

        Regards,
        Smart Parking System Team 🚗
        """
        from_email = f'Smart Parking System <{settings.EMAIL_HOST_USER}>'

        # ✅ Send Email
        Thread(target=send_mail, args=(subject, message, from_email, [email], False)).start()

        # ✅ Store Email in Session (Optional: Useful for pre-filling fields)
        request.session['email'] = email

        # ✅ Success Message
        messages.success(request, '✅ OTP Sent Successfully! Check your Inbox.')
        return redirect('booking_dashboard')
    



def verify_otp(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        otp = request.POST.get('otp')

        # ✅ Debugging: Print the received values
        print(f"Received Email: {email}, Received OTP: {otp}")

        # ✅ Validate email and OTP presence
        if not email or not otp:
            messages.error(request, '❌ Email and OTP fields cannot be empty.')
            return redirect('booking_dashboard')

        # ✅ Convert OTP to integer safely
        try:
            otp = int(otp)
        except (ValueError, TypeError):
            messages.error(request, '❌ Invalid OTP format. Enter numbers only.')
            return redirect('booking_dashboard')

        # ✅ Retrieve stored OTP from cache
        stored_otp = cache.get(email)

        # ✅ Debugging: Print stored OTP for comparison
        print(f"Stored OTP for {email}: {stored_otp}")

        # ✅ Ensure an OTP was actually sent and exists
        if stored_otp is None:
            messages.error(request, '❌ OTP has expired or was not requested. Please request a new OTP.')
            return redirect('booking_dashboard')

        # ✅ Correctly compare received OTP with stored OTP
        if otp != stored_otp:  # Ensure comparison is exact
            messages.error(request, '❌ Invalid OTP. Please try again!')
            return redirect('booking_dashboard')

        # ✅ OTP is correct, delete it to prevent reuse
        cache.delete(email)

        # ✅ Success Message
        messages.success(request, '✅ Email Verified Successfully!')
        return redirect('booking_dashboard')
    








    
def payment_page(request):
    context = {
        "car_number": "MH12AB1234",
        "name": "John Doe",
        "email": "johndoe@example.com",
        "slot": "A5",
        "location": "Downtown Parking",
        "amount": 150.00
    }
    return render(request, "payment.html", context)










    
def contact_view(request):
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Your message has been sent successfully!")
            return redirect('contact')
    else:
        form = ContactForm()
    
    return render(request, 'contact.html', {'form': form})




def about_us(request):
    return render(request, 'about.html')